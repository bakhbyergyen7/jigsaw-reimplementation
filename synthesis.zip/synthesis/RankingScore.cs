﻿using Microsoft.ProgramSynthesis;
using Microsoft.ProgramSynthesis.AST;
using Microsoft.ProgramSynthesis.Features;
using ASTtransformation;

namespace TestSemantics
{
    public class RankingScore : Feature<double>
    {
        public RankingScore(Grammar grammar) : base(grammar, "Score")
        {
        }

        protected override double GetFeatureValueForVariable(VariableNode variable)
        {
            return 0;
        }

        [FeatureCalculator(nameof(Semantics.RemoveKind))]
        public static double RemoveKind(double v, double kind)
        {
            return 0;
        }

        [FeatureCalculator(nameof(Semantics.UpdateKind))]
        public static double UpdateKind(double v, double kind, double new_value)
        {
            return 0;
        }

        // for literal 'kind'
        [FeatureCalculator("kind", Method = CalculationMethod.FromLiteral)]
        public static double Kind(string kind)
        {
            return 0;
        }

        // for literal 'new_value'
        [FeatureCalculator("new_value", Method = CalculationMethod.FromLiteral)]
        public static double NewValue(string new_value)
        {
            return 0;
        }
    }
}