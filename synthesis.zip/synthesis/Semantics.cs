using System;
using System.Collections.Generic;

namespace ASTtransformation
{
    public class MyAST
    {
        public string Kind { get; set; }
        public string Value { get; set; }
        public string Path { get; set; }
        public List<MyAST> Children { get; set; }

        public MyAST(string kind, string value, string path, IEnumerable<MyAST> children)
        {
            Kind = kind;
            Value = value;
            Path = path;
            Children = new List<MyAST>(children);
        }
        // tostring
        public override string ToString()
        {
            // Start with the current node
            string result = $"{Kind}({Value}, {Path})";

            // If the node has children, append them recursively
            if (Children != null && Children.Count > 0)
            {
                result += "\n  Children: [\n";
                foreach (var child in Children)
                {
                    result += "    " + child.ToString().Replace("\n", "\n    ") + "\n";
                }
                result += "  ]";
            }

            return result;
        }
        // traverseKind() - Traverse the AST and store all kind values in a list
        public void TraverseKind(List<string> kindValues)
        {
            // Add the kind of the current node to the list
            kindValues.Add(Kind);

            // Recursively traverse the children
            foreach (var child in Children)
            {
                child.TraverseKind(kindValues);
            }
        }

        // traverseValue() - Traverse the AST and store all value values in a list
        public void TraverseValue(List<string> valueValues)
        {
            // Add the value of the current node to the list
            valueValues.Add(Value);

            // Recursively traverse the children
            foreach (var child in Children)
            {
                child.TraverseValue(valueValues);
            }
        }
    }

    public static class Semantics
    {
        // AST TRANSFORMATION OPERATIONS
        // 1. RemoveKind(root, kind) - Remove all nodes of a given kind from the AST
        public static MyAST RemoveKind(MyAST root, string kind)
        {
            if (root == null)
            {
                return null;
            }

            // Create a new list to store the children that are not of the given kind
            var newChildren = new List<MyAST>();

            foreach (var child in root.Children)
            {
                // Recursively remove nodes of the given kind from the children
                var updatedChild = RemoveKind(child, kind);
                if (updatedChild != null)
                {
                    newChildren.Add(updatedChild);
                }
            }

            // Update the children of the current node
            root.Children = newChildren;

            // If the current node is of the given kind, return null to remove it
            return root.Kind == kind ? null : root;
        }

        // 2. UpdateKind(root, kind, new_value) - Update the value of all nodes of a given kind
        public static MyAST UpdateKind(MyAST root, string kind, string new_value)
        {
            if (root == null)
            {
                return null;
            }

            // Create a new list to store the updated children
            var newChildren = new List<MyAST>();

            foreach (var child in root.Children)
            {
                // Recursively update the value of nodes of the given kind in the children
                var updatedChild = UpdateKind(child, kind, new_value);
                if (updatedChild != null)
                {
                    newChildren.Add(updatedChild);
                }
            }

            // Update the children of the current node
            root.Children = newChildren;

            // If the current node is of the given kind, update its value
            if (root.Kind == kind)
            {
                root.Value = new_value;
            }

            return root;
        }
    }
}