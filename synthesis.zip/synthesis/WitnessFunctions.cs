﻿
using System.Collections.Generic;
using Microsoft.ProgramSynthesis;
using Microsoft.ProgramSynthesis.Learning;
using Microsoft.ProgramSynthesis.Rules;
using Microsoft.ProgramSynthesis.Specifications;
using ASTtransformation;

namespace TestSemantics
{
    public class WitnessFunctions : DomainLearningLogic
    {
        public WitnessFunctions(Grammar grammar) : base(grammar)
        {
        }

        // public static class Learners
        // {
        //     public static string[] StringGen = {"Kind1", "Kind2"};
        // }

        [WitnessFunction(nameof(Semantics.RemoveKind), 1)]
        public ExampleSpec WitnessRemoveKind(GrammarRule rule, ExampleSpec spec)
        {
            var examples = new Dictionary<State, object>();
            foreach (KeyValuePair<State, object> example in spec.Examples)
            {
                State inputState = example.Key;
                var input = inputState[rule.Body[0]] as MyAST;
                var output = example.Value as MyAST;

                // Traverse the output AST and store all kind values in a list
                var output_kindValues = new List<string>();
                output.TraverseKind(output_kindValues);

                // Traverse the input AST and store all kind values in a list
                var input_kindValues = new List<string>();
                input.TraverseKind(input_kindValues);

                // Make the two list unique
                var unique_output_kindValues = new HashSet<string>(output_kindValues);
                var unique_input_kindValues = new HashSet<string>(input_kindValues);

                // Find the difference between the two lists
                var diff = new List<string>(unique_input_kindValues);
                diff.RemoveAll(unique_output_kindValues.Contains);

                // extract the string from the diff list
                var kindToRemove = diff.Count > 0 ? diff[0] : "";
                if (kindToRemove == "")
                {
                    return new ExampleSpec(examples);
                }

                examples[inputState] = kindToRemove;             
            }
            return new ExampleSpec(examples);
        }

        [WitnessFunction(nameof(Semantics.UpdateKind), 1)]
        public ExampleSpec WitnessUpdateKind(GrammarRule rule, ExampleSpec spec)
        {
            var examples = new Dictionary<State, object>();
            foreach (KeyValuePair<State, object> example in spec.Examples)
            {
                State inputState = example.Key;
                var input = inputState[rule.Body[0]] as MyAST;
                var output = example.Value as MyAST;

                // Traverse the output AST and store all kind values in a list
                var output_kindValues = new List<string>();
                output.TraverseKind(output_kindValues);

                // Traverse the input AST and store all kind values in a list
                var input_kindValues = new List<string>();
                input.TraverseKind(input_kindValues);

                // Check if output_kindValues is equal to input_kindValues
                if (input_kindValues.SequenceEqual(output_kindValues))
                {
                    // Traverse both trees and find the node that has different value
                    string kindToUpdate = FindKindWithDifferentValue(input, output);
                    if (kindToUpdate != null)
                    {
                        examples[inputState] = kindToUpdate;
                    }
                }
     
            }
            return new ExampleSpec(examples);
        }
        private static string FindKindWithDifferentValue(MyAST input, MyAST output)
        {
            // Base case: if one of the nodes is null, traversal ends here
            if (input == null || output == null)
            {
                return null;
            }

            // Check if the current nodes have the same kind but different values
            if (input.Kind == output.Kind && input.Value != output.Value)
            {
                return input.Kind;
            }

            // Check if the number of children is different
            if (input.Children.Count != output.Children.Count)
            {
                return null;
            }

            // Recursively check all children
            for (int i = 0; i < input.Children.Count; i++)
            {
                string kind = FindKindWithDifferentValue(input.Children[i], output.Children[i]);
                if (kind != null)
                {
                    return kind;
                }
            }

            // If no mismatched value is found, return null
            return null;
        }

        [WitnessFunction(nameof(Semantics.UpdateKind), 2)]
        public ExampleSpec WitnessUpdateKindValue(GrammarRule rule, ExampleSpec spec)
        {
            var examples = new Dictionary<State, object>();
            foreach (KeyValuePair<State, object> example in spec.Examples)
            {
                State inputState = example.Key;
                var input = inputState[rule.Body[0]] as MyAST;
                var output = example.Value as MyAST;

                // Traverse the output AST and store all values in a list
                var output_valueValues = new List<string>();
                output.TraverseValue(output_valueValues);

                // Traverse the input AST and store all values in a list
                var input_valueValues = new List<string>();
                input.TraverseValue(input_valueValues);

                // make the two list unique
                var unique_output_valueValues = new HashSet<string>(output_valueValues);
                var unique_input_valueValues = new HashSet<string>(input_valueValues);

                // Find the difference between the two lists
                var diff = new List<string>(unique_input_valueValues);
                diff.RemoveAll(unique_output_valueValues.Contains);

                // extract the string from the diff list
                var valueToUpdate = diff.Count > 0 ? diff[0] : "";
                // if valueToUpdate is "", return null
                if (valueToUpdate == "")
                {
                    return new ExampleSpec(examples);
                }

                examples[inputState] = valueToUpdate;
            }
            return new ExampleSpec(examples);
        }
    }


}
